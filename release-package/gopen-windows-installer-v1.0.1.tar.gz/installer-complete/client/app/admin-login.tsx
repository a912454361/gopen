export { default } from "@/screens/admin-login";
