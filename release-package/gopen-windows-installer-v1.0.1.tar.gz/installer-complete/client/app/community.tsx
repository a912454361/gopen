export { default } from "@/screens/community";
