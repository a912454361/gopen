#!/bin/bash

echo "========================================"
echo "  G open 官网 → GitHub Pages 部署"
echo "========================================"
echo ""

# GitHub 用户名
GITHUB_USER="a912454361"
REPO_NAME="gopen-website"

# 检查 git
if ! command -v git &> /dev/null; then
    echo "❌ Git 未安装，请先安装 Git"
    exit 1
fi

echo "✅ Git 已安装"

# 初始化仓库
if [ -d ".git" ]; then
    echo "Git 仓库已存在"
else
    git init
    echo "✅ 已初始化 Git 仓库"
fi

# 添加所有文件
git add .
echo "✅ 已添加所有文件"

# 提交
git commit -m "Deploy G open website to GitHub Pages"
echo "✅ 已创建提交"

# 检查远程仓库
if git remote | grep -q "origin"; then
    git remote set-url origin https://github.com/$GITHUB_USER/$REPO_NAME.git
    echo "✅ 已更新远程仓库地址"
else
    git remote add origin https://github.com/$GITHUB_USER/$REPO_NAME.git
    echo "✅ 已添加远程仓库"
fi

# 切换到 main 分支
git branch -M main
echo "✅ 已切换到 main 分支"

echo ""
echo "========================================"
echo "  下一步操作"
echo "========================================"
echo ""
echo "1. 访问 https://github.com/new 创建仓库"
echo "   仓库名: $REPO_NAME"
echo "   设置为: Public"
echo "   不要勾选 README/gitignore/license"
echo ""
echo "2. 创建完成后，运行以下命令推送代码:"
echo ""
echo "   git push -u origin main"
echo ""
echo "3. 启用 GitHub Pages:"
echo "   访问 https://github.com/$GITHUB_USER/$REPO_NAME/settings/pages"
echo "   Source 选择: main 分支"
echo "   点击 Save"
echo ""
echo "4. 配置域名解析 (在阿里云/腾讯云):"
echo "   A记录: @ → 185.199.108.153"
echo "   A记录: @ → 185.199.109.153"
echo "   A记录: @ → 185.199.110.153"
echo "   A记录: @ → 185.199.111.153"
echo "   CNAME: www → $GITHUB_USER.github.io"
echo ""
echo "5. 等待 5-10 分钟后访问:"
echo "   https://woshiguotao.cn"
echo ""
