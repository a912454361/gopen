export { default } from "@/screens/payment";
